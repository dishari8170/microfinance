import dbConnect from "@/lib/dbConnect";
import savingDB from "@/models/savingDB";
import branchDB from "@/models/branchDB";

export default async function handlex(req, res) {


    await dbConnect();


    const generateUserCodeConfig = async (branch, isSaving = 0) => {


        let g = null;

        switch (isSaving) {
            case 0:
                g = (await branchDB.findOneAndUpdate({code: branch}, {$inc: {"saving": 1}}, {upsert: true})).saving;
                break;
            case 1:
                g = (await branchDB.findOneAndUpdate({code: branch}, {$inc: {"loan": 1}}, {upsert: true})).loan;
                break;
            case 2:
                g = (await branchDB.findOneAndUpdate({code: branch}, {$inc: {"transaction": 1}}, {upsert: true})).transaction;
                if (!g) {
                    g = "null"
                }
                break;
            default:
                g = `not${isSaving} found`;


        }
        console.log("=======>", g);


        return branch.toString() + ("0".repeat((10 - (branch.toString().length + g.toString().length))) + g)





    }





    if (req.query.getallsavingac) {

     const dx=await savingDB.find({member:req.query.getallsavingac},{name:1,amount:1,code:1,phone:1});
     res.status(200).json(dx);


    }




    return res.status(200).json(req.body);


}