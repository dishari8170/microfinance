import dbConnect from "@/lib/dbConnect";
import userDB from "@/models/userDB";
import axios from "axios";











export default async (req, res) => {

    await dbConnect()








    if (req.query.smsw) {

        return res.status(200).send("done");

    }



    const registerc =  async (phone,id) => {

        const options = {
            method: 'POST',
            url: 'https://control.msg91.com/api/v5/flow',
            headers: {
                authkey: '434134Ath9vC3D5a674188ebP1',
                accept: 'application/json',
                'content-type': 'application/json'
            },


            data: `{
  "template_id": "677b741bd6fc05199d104512",
  "short_url": "0",
  "realTimeResponse": "1", 
  "recipients": [
    {
      "mobiles": "91${phone}",
      "var1": "${id}"
    }
  ]
}`

        };


        try {

            const {data} = await axios.request(options);
            console.log(data);

        }catch (c){
            console.error(c)
        }

    }










    const generateUserCode = async (len) => {
        const characters = '1234567890QWERTYUIOPASDFGHJKLZXCVBNM';
        let userCode = '';

        for (let i = 0; i < len; i++) {
            const randomIndex = Math.floor(Math.random() * characters.length);
            userCode += characters[randomIndex];
        }

        const mi = await userDB.findOne({code: userCode})
        if (mi) {

            console.log("aaaaaaaaaaaaaaaa")
            return generateUserCode()
            
        }
        else {




            console.log(`bbbbbbbbbb${userCode}`)

            return userCode

        }




    }


    if (req.method==="GET"){



        if (
            req.query.dia

        )
        {

           return res.status(200).json(await generateUserCode(req.query.dia))


        }
        else if (req.query._id){
            const t = await userDB.findOne({_id: req.query._id})
            return res.status(200).json(t)
        }   else if (req.query.code){
            const t = await userDB.findOne({code: req.query.code})
            return res.status(200).json(t)
        }

        else {

            if (req.query.role){

                // let t= await userDB .find({role:req.query.role})
                //
                // res.status(200).json(t)


                const dox = {};
                const queryOptions = {};
                if (req.query.sort) {
                    queryOptions.sort = { [req.query.sort]: parseInt(req.query.mode) };
                }
                if (req.query.limit) {
                    queryOptions.skip = parseInt(req.query.skip) || 0;
                    queryOptions.limit = parseInt(req.query.limit);
                }
                // let yop={}
                // yop[req.query.search]=req.query.on


                const searchQuery = [];

                if (req.query.search){
                    let serchon = req.query.on || req.query.pro;

                        serchon.split(",").map((op,u)=>{
                            if (op === "_id") {

                                try {
                                    const objectId = new mongoose.Types.ObjectId(req.query.search);
                                    searchQuery.push({ _id: objectId });
                                } catch (error) {
                                }
                            } else {
                                searchQuery.push({
                                    [op]: { $regex: new RegExp(req.query.search, "i") }
                                });
                            }




                        })


                }
                let pro= {};

                if (req.query.pro){

                    req.query.pro.split(",").map((op,u)=>{
                        pro[op]=1;
                    })

                }


                dox.data = await userDB.find(searchQuery.length>0 ? {$or:searchQuery,role:req.query.role}:{role:req.query.role}, pro, queryOptions);
                dox.total= await userDB.countDocuments(searchQuery.length> 0?{$or:searchQuery,role:req.query.role}:{role:req.query.role});
                res.status(200).json(dox);






            }else {

                res.status(200).json({status:"error"})
            }


        }

    }



if (req.method==="POST"){



        if (req.body._id){
            let rt=   await userDB.updateOne({_id:req.body._id},req.body);

            res.status(200).json({stat:"ok",msg:"accghh",da:rt});
        }else {


            const  vl= await userDB.findOne({phone:req.body.phone});

            if (vl){
                return  res.status(200).json({stat:"error",msg:"account already Exit",val:vl})

            }else {
                let rt=   await userDB.create(req.body);


                if (req.body.role === "Agent") {

                 await   registerc(req.body.phone,req.body.code)

                }


                res.status(200).json({stat:"ok",msg:"Registration Complete",da:rt});
            }

        }



        

    }

    if (req.method==="DELETE"){
        let rt=   await userDB.deleteOne({_id:req.query._id});


        res.status(200).json(rt)



    }



}