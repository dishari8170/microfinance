import mongoose from "mongoose";



const homeschema = new mongoose.Schema({
    parent :String,
    code:String,
    type:String,
    customer:String,
    name:String,
    phone:String,
    term:Number,
    amount:Number,
    bank:{
        name:String,
        ac:String,
        ifsc:String,
        ben:String
    },
    doc:{ type: Map,
        of: String,
        default: {},

    },
});




module.exports = mongoose.models.loanDB || mongoose.model("loanDB", homeschema);


